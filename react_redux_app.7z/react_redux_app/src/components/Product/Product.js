import React, { Component } from 'react';
import { connect } from 'react-redux';
import { addToCart, removeFromCart, isInCart } from '../../reducers/cart';
import './Product.css';

class Product extends Component {
    addToScart = () => {
       
    const { id, addToCart, removeFromCart, isInCart } = this.props;

        if (isInCart) { 
            removeFromCart(id);
        } else {
            addToCart(id);
        }
    }

    render() {
        const { name, price, image, isInCart } = this.props;
        

        return (
            <div className="product thumbnail">
            <img src={image} alt="" />
                <div>
                    <h4>{name}</h4>
                <div className="prodprice">INR {price}</div>
                    <div>
                        <button
                        className={isInCart ? 'btn btn-danger' : 'btn btn-primary'}
                            onClick={this.addToScart}>
                            {isInCart ? 'Remove' : 'Add to cart'}
                    </button>
                    </div>
                    </div>
            </div>
            );
    }
}

const mapStateToProps = (state, props) => {
    return {
        isInCart: isInCart(state, props)
    }
}

const mapDispatchToProps = (dispatch) => ({
    addToCart: (id) => dispatch(addToCart(id)),
    removeFromCart: (id) => dispatch(removeFromCart(id))
})

export default connect(mapStateToProps, mapDispatchToProps)(Product);

