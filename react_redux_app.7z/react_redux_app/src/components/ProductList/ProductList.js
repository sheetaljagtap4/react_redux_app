import React from 'react';
import Product from '../Product/Product';
import './ProductList.css';
import { connect } from 'react-redux';
import { getProducts } from '../../reducers/products';

const ProductList = ({ products }) => {
    return (
        <div>
            <h3 className="prod_header">Today's deals</h3>
            <ul className="product">
              {products.map(product => (
                  <li key={product.id} className="product_align col-md-4">


                    <Product {...product} />

                    
                  </li>
              ))}
            </ul>
        </div>
    );
}

const mapStateToProps = (state, props) => {
    return {
        products: getProducts(state, props)
    }
}

export default connect(mapStateToProps)(ProductList);

