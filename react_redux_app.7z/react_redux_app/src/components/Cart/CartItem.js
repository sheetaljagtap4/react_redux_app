import React from 'react';

const CartItem = ({ name, price }) => {
    
    return (
        <div>
            <div>
            <span>{name}</span>
            </div>
            <div>{price} </div>
        </div>
    );
}
export default CartItem;
