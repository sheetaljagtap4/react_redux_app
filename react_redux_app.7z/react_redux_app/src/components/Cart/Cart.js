import React from 'react';
import CartItem from './CartItem';
import '../../App.css'
import { connect } from 'react-redux';
import { getItems, getTotal } from '../../reducers/cart';

const Cart = ({ items, total }) => {
    return (
        <div>
            <h3 className="header">Shopping Cart</h3>
                <div className="panel panel-default">
                    <div className="panel-body">
                    {items.length > 0 && (
                        <div>
                            {items.map(item => (
                                <CartItem key={item.id} {...item} />    
                            ))} 
                        </div>
                    )}
                      
                        <div><b>Total Rs.: {total}</b></div>
                    </div>
                    </div>
             </div>
    );
}

const mapStateToProps = (state) => {
  
    return {
        items: getItems(state),
        total: getTotal(state)
    }
}

export default connect(mapStateToProps)(Cart);

