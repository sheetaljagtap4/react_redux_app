import { getProduct } from '../reducers/products';


const initialState = {items: [] };

export default function cart(state = initialState, action = {}) {
    switch (action.type) {
        case 'ADD':
            return handleCartAdd(state, action.payload);
        case 'REMOVE':
            return handleCartRemove(state, action.payload);
        default:
            return state;
    }
}

function handleCartAdd(state, payload) {
    

    return {
        ...state,
        items: [ ...state.items, payload.productId ]
    };
}

function handleCartRemove(state, payload) {
    return {
        ...state,
        items: state.items.filter(id => id !== payload.productId)
    };
}


export function addToCart(productId) {
    return {
        type: 'ADD',
        payload: {
            productId
        }
    }
}

export function removeFromCart(productId) {
    return {
        type: 'REMOVE',
        payload: {
            productId
        }
    }
}

export function isInCart(state, props) {
    
    return state.cart.items.indexOf(props.id) !== -1;
}

export function getItems(state) {
    
    return state.cart.items.map(id => getProduct(state, { id }));
}

export function getTotal(state) {
    return state.cart.items.reduce((elem, id) => {
        const item = getProduct(state, { id });
        return elem + item.price;
    }, 0);
}
