const data = [
  {
    id: 1,
    name: 'iPhone Charger Sticker Faces Set',
    price: 1499,
    image: '../images/pic1.jpg',
  },
  {
    id: 2,
    name: 'Magnetic Mounting iPhone Case',
    price: 2249,
    image: 'images/pic2.jpg',
  },
  {
    id: 3,
    name: 'Phone Charging Bracelet',
    price: 1239,
    image: 'images/pic3.jpg',
  },
  {
    id: 4,
    name: 'PhoneSoap Smartphone Sanitizer',
    price: 1119,
    image: 'images/pic4.jpg',
  },
  {
    id: 5,
    name: 'Color-Changing Touch Speaker',
    price: 2599,
    image: 'images/pic5.jpg',
  },
  {
    id: 6,
    name: 'Timbrefone Acoustic Phone Amp',
    price: 1149,
    image: 'images/pic6.jpg',
  }
];

export default data;
